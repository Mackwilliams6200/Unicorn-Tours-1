# Unicorn Space Tours

[**Created during the Learn From Steph course >**](https://learnfromsteph.dev)

## Building and running on localhost

First install dependencies:

```sh
npm install
```

Run the project with automatic reloading:

```sh
npm start
```
