# Learn Web Development With Steph

## Getting Started: Setup Working Environment

This directory is a blank project that will be the foundation built upon for each lesson in this course.

[**Course information >**](https://learnfromsteph.dev)

## Building and running on localhost

First install dependencies:

```sh
npm install
```

Run the project with automatic reloading:

```sh
npm start
```
