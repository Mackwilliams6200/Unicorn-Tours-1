# Learn Web Development With Steph

## Capstone 11: Navigation

[**Course information >**](https://learnfromsteph.dev)

## Building and running on localhost

First install dependencies:

```sh
npm install
```

Run the project with automatic reloading:

```sh
npm start
```
