# Learn Web Development With Steph

## Capstone #3: Translating a Design into Semantic HTML

[**Course information >**](https://learnfromsteph.dev)

## Building and running on localhost

First install dependencies:

```sh
npm install
```

Run the project with automatic reloading:

```sh
npm start
```
